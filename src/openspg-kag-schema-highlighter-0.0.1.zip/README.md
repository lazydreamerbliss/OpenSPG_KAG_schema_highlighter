# OpenSPG_KAG_schema_highlighter

VSCode extension for syntax highlight of OpenSPG-KAG schema
- https://github.com/OpenSPG/KAG
